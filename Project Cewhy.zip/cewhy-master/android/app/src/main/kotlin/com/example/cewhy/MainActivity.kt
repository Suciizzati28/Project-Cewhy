package com.example.cewhy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
